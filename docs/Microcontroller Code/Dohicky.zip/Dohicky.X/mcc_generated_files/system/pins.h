/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA3 aliases
#define Temp_Coms_TX_TRIS                 TRISAbits.TRISA3
#define Temp_Coms_TX_LAT                  LATAbits.LATA3
#define Temp_Coms_TX_PORT                 PORTAbits.RA3
#define Temp_Coms_TX_WPU                  WPUAbits.WPUA3
#define Temp_Coms_TX_OD                   ODCONAbits.ODCA3
#define Temp_Coms_TX_ANS                  ANSELAbits.ANSELA3
#define Temp_Coms_TX_SetHigh()            do { LATAbits.LATA3 = 1; } while(0)
#define Temp_Coms_TX_SetLow()             do { LATAbits.LATA3 = 0; } while(0)
#define Temp_Coms_TX_Toggle()             do { LATAbits.LATA3 = ~LATAbits.LATA3; } while(0)
#define Temp_Coms_TX_GetValue()           PORTAbits.RA3
#define Temp_Coms_TX_SetDigitalInput()    do { TRISAbits.TRISA3 = 1; } while(0)
#define Temp_Coms_TX_SetDigitalOutput()   do { TRISAbits.TRISA3 = 0; } while(0)
#define Temp_Coms_TX_SetPullup()          do { WPUAbits.WPUA3 = 1; } while(0)
#define Temp_Coms_TX_ResetPullup()        do { WPUAbits.WPUA3 = 0; } while(0)
#define Temp_Coms_TX_SetPushPull()        do { ODCONAbits.ODCA3 = 0; } while(0)
#define Temp_Coms_TX_SetOpenDrain()       do { ODCONAbits.ODCA3 = 1; } while(0)
#define Temp_Coms_TX_SetAnalogMode()      do { ANSELAbits.ANSELA3 = 1; } while(0)
#define Temp_Coms_TX_SetDigitalMode()     do { ANSELAbits.ANSELA3 = 0; } while(0)

// get/set RA4 aliases
#define Temp_Coms_RX_TRIS                 TRISAbits.TRISA4
#define Temp_Coms_RX_LAT                  LATAbits.LATA4
#define Temp_Coms_RX_PORT                 PORTAbits.RA4
#define Temp_Coms_RX_WPU                  WPUAbits.WPUA4
#define Temp_Coms_RX_OD                   ODCONAbits.ODCA4
#define Temp_Coms_RX_ANS                  ANSELAbits.ANSELA4
#define Temp_Coms_RX_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define Temp_Coms_RX_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define Temp_Coms_RX_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define Temp_Coms_RX_GetValue()           PORTAbits.RA4
#define Temp_Coms_RX_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define Temp_Coms_RX_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define Temp_Coms_RX_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define Temp_Coms_RX_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define Temp_Coms_RX_SetPushPull()        do { ODCONAbits.ODCA4 = 0; } while(0)
#define Temp_Coms_RX_SetOpenDrain()       do { ODCONAbits.ODCA4 = 1; } while(0)
#define Temp_Coms_RX_SetAnalogMode()      do { ANSELAbits.ANSELA4 = 1; } while(0)
#define Temp_Coms_RX_SetDigitalMode()     do { ANSELAbits.ANSELA4 = 0; } while(0)

// get/set RA6 aliases
#define TEMP_LED_1_TRIS                 TRISAbits.TRISA6
#define TEMP_LED_1_LAT                  LATAbits.LATA6
#define TEMP_LED_1_PORT                 PORTAbits.RA6
#define TEMP_LED_1_WPU                  WPUAbits.WPUA6
#define TEMP_LED_1_OD                   ODCONAbits.ODCA6
#define TEMP_LED_1_ANS                  ANSELAbits.ANSELA6
#define TEMP_LED_1_SetHigh()            do { LATAbits.LATA6 = 1; } while(0)
#define TEMP_LED_1_SetLow()             do { LATAbits.LATA6 = 0; } while(0)
#define TEMP_LED_1_Toggle()             do { LATAbits.LATA6 = ~LATAbits.LATA6; } while(0)
#define TEMP_LED_1_GetValue()           PORTAbits.RA6
#define TEMP_LED_1_SetDigitalInput()    do { TRISAbits.TRISA6 = 1; } while(0)
#define TEMP_LED_1_SetDigitalOutput()   do { TRISAbits.TRISA6 = 0; } while(0)
#define TEMP_LED_1_SetPullup()          do { WPUAbits.WPUA6 = 1; } while(0)
#define TEMP_LED_1_ResetPullup()        do { WPUAbits.WPUA6 = 0; } while(0)
#define TEMP_LED_1_SetPushPull()        do { ODCONAbits.ODCA6 = 0; } while(0)
#define TEMP_LED_1_SetOpenDrain()       do { ODCONAbits.ODCA6 = 1; } while(0)
#define TEMP_LED_1_SetAnalogMode()      do { ANSELAbits.ANSELA6 = 1; } while(0)
#define TEMP_LED_1_SetDigitalMode()     do { ANSELAbits.ANSELA6 = 0; } while(0)

// get/set RA7 aliases
#define TEMP_LED_2_TRIS                 TRISAbits.TRISA7
#define TEMP_LED_2_LAT                  LATAbits.LATA7
#define TEMP_LED_2_PORT                 PORTAbits.RA7
#define TEMP_LED_2_WPU                  WPUAbits.WPUA7
#define TEMP_LED_2_OD                   ODCONAbits.ODCA7
#define TEMP_LED_2_ANS                  ANSELAbits.ANSELA7
#define TEMP_LED_2_SetHigh()            do { LATAbits.LATA7 = 1; } while(0)
#define TEMP_LED_2_SetLow()             do { LATAbits.LATA7 = 0; } while(0)
#define TEMP_LED_2_Toggle()             do { LATAbits.LATA7 = ~LATAbits.LATA7; } while(0)
#define TEMP_LED_2_GetValue()           PORTAbits.RA7
#define TEMP_LED_2_SetDigitalInput()    do { TRISAbits.TRISA7 = 1; } while(0)
#define TEMP_LED_2_SetDigitalOutput()   do { TRISAbits.TRISA7 = 0; } while(0)
#define TEMP_LED_2_SetPullup()          do { WPUAbits.WPUA7 = 1; } while(0)
#define TEMP_LED_2_ResetPullup()        do { WPUAbits.WPUA7 = 0; } while(0)
#define TEMP_LED_2_SetPushPull()        do { ODCONAbits.ODCA7 = 0; } while(0)
#define TEMP_LED_2_SetOpenDrain()       do { ODCONAbits.ODCA7 = 1; } while(0)
#define TEMP_LED_2_SetAnalogMode()      do { ANSELAbits.ANSELA7 = 1; } while(0)
#define TEMP_LED_2_SetDigitalMode()     do { ANSELAbits.ANSELA7 = 0; } while(0)

// get/set RB0 aliases
#define IO_RB0_TRIS                 TRISBbits.TRISB0
#define IO_RB0_LAT                  LATBbits.LATB0
#define IO_RB0_PORT                 PORTBbits.RB0
#define IO_RB0_WPU                  WPUBbits.WPUB0
#define IO_RB0_OD                   ODCONBbits.ODCB0
#define IO_RB0_ANS                  ANSELBbits.ANSELB0
#define IO_RB0_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define IO_RB0_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define IO_RB0_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define IO_RB0_GetValue()           PORTBbits.RB0
#define IO_RB0_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define IO_RB0_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define IO_RB0_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define IO_RB0_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define IO_RB0_SetPushPull()        do { ODCONBbits.ODCB0 = 0; } while(0)
#define IO_RB0_SetOpenDrain()       do { ODCONBbits.ODCB0 = 1; } while(0)
#define IO_RB0_SetAnalogMode()      do { ANSELBbits.ANSELB0 = 1; } while(0)
#define IO_RB0_SetDigitalMode()     do { ANSELBbits.ANSELB0 = 0; } while(0)

// get/set RB1 aliases
#define IO_RB1_TRIS                 TRISBbits.TRISB1
#define IO_RB1_LAT                  LATBbits.LATB1
#define IO_RB1_PORT                 PORTBbits.RB1
#define IO_RB1_WPU                  WPUBbits.WPUB1
#define IO_RB1_OD                   ODCONBbits.ODCB1
#define IO_RB1_ANS                  ANSELBbits.ANSELB1
#define IO_RB1_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define IO_RB1_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define IO_RB1_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define IO_RB1_GetValue()           PORTBbits.RB1
#define IO_RB1_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define IO_RB1_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define IO_RB1_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define IO_RB1_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define IO_RB1_SetPushPull()        do { ODCONBbits.ODCB1 = 0; } while(0)
#define IO_RB1_SetOpenDrain()       do { ODCONBbits.ODCB1 = 1; } while(0)
#define IO_RB1_SetAnalogMode()      do { ANSELBbits.ANSELB1 = 1; } while(0)
#define IO_RB1_SetDigitalMode()     do { ANSELBbits.ANSELB1 = 0; } while(0)

// get/set RB3 aliases
#define IO_RB3_TRIS                 TRISBbits.TRISB3
#define IO_RB3_LAT                  LATBbits.LATB3
#define IO_RB3_PORT                 PORTBbits.RB3
#define IO_RB3_WPU                  WPUBbits.WPUB3
#define IO_RB3_OD                   ODCONBbits.ODCB3
#define IO_RB3_ANS                  ANSELBbits.ANSELB3
#define IO_RB3_SetHigh()            do { LATBbits.LATB3 = 1; } while(0)
#define IO_RB3_SetLow()             do { LATBbits.LATB3 = 0; } while(0)
#define IO_RB3_Toggle()             do { LATBbits.LATB3 = ~LATBbits.LATB3; } while(0)
#define IO_RB3_GetValue()           PORTBbits.RB3
#define IO_RB3_SetDigitalInput()    do { TRISBbits.TRISB3 = 1; } while(0)
#define IO_RB3_SetDigitalOutput()   do { TRISBbits.TRISB3 = 0; } while(0)
#define IO_RB3_SetPullup()          do { WPUBbits.WPUB3 = 1; } while(0)
#define IO_RB3_ResetPullup()        do { WPUBbits.WPUB3 = 0; } while(0)
#define IO_RB3_SetPushPull()        do { ODCONBbits.ODCB3 = 0; } while(0)
#define IO_RB3_SetOpenDrain()       do { ODCONBbits.ODCB3 = 1; } while(0)
#define IO_RB3_SetAnalogMode()      do { ANSELBbits.ANSELB3 = 1; } while(0)
#define IO_RB3_SetDigitalMode()     do { ANSELBbits.ANSELB3 = 0; } while(0)

// get/set RC0 aliases
#define IO_RC0_TRIS                 TRISCbits.TRISC0
#define IO_RC0_LAT                  LATCbits.LATC0
#define IO_RC0_PORT                 PORTCbits.RC0
#define IO_RC0_WPU                  WPUCbits.WPUC0
#define IO_RC0_OD                   ODCONCbits.ODCC0
#define IO_RC0_ANS                  ANSELCbits.ANSELC0
#define IO_RC0_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define IO_RC0_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define IO_RC0_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define IO_RC0_GetValue()           PORTCbits.RC0
#define IO_RC0_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define IO_RC0_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define IO_RC0_SetPullup()          do { WPUCbits.WPUC0 = 1; } while(0)
#define IO_RC0_ResetPullup()        do { WPUCbits.WPUC0 = 0; } while(0)
#define IO_RC0_SetPushPull()        do { ODCONCbits.ODCC0 = 0; } while(0)
#define IO_RC0_SetOpenDrain()       do { ODCONCbits.ODCC0 = 1; } while(0)
#define IO_RC0_SetAnalogMode()      do { ANSELCbits.ANSELC0 = 1; } while(0)
#define IO_RC0_SetDigitalMode()     do { ANSELCbits.ANSELC0 = 0; } while(0)

// get/set RC1 aliases
#define IO_RC1_TRIS                 TRISCbits.TRISC1
#define IO_RC1_LAT                  LATCbits.LATC1
#define IO_RC1_PORT                 PORTCbits.RC1
#define IO_RC1_WPU                  WPUCbits.WPUC1
#define IO_RC1_OD                   ODCONCbits.ODCC1
#define IO_RC1_ANS                  ANSELCbits.ANSELC1
#define IO_RC1_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define IO_RC1_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define IO_RC1_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define IO_RC1_GetValue()           PORTCbits.RC1
#define IO_RC1_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define IO_RC1_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define IO_RC1_SetPullup()          do { WPUCbits.WPUC1 = 1; } while(0)
#define IO_RC1_ResetPullup()        do { WPUCbits.WPUC1 = 0; } while(0)
#define IO_RC1_SetPushPull()        do { ODCONCbits.ODCC1 = 0; } while(0)
#define IO_RC1_SetOpenDrain()       do { ODCONCbits.ODCC1 = 1; } while(0)
#define IO_RC1_SetAnalogMode()      do { ANSELCbits.ANSELC1 = 1; } while(0)
#define IO_RC1_SetDigitalMode()     do { ANSELCbits.ANSELC1 = 0; } while(0)

// get/set RC2 aliases
#define Light_Coms_TX_TRIS                 TRISCbits.TRISC2
#define Light_Coms_TX_LAT                  LATCbits.LATC2
#define Light_Coms_TX_PORT                 PORTCbits.RC2
#define Light_Coms_TX_WPU                  WPUCbits.WPUC2
#define Light_Coms_TX_OD                   ODCONCbits.ODCC2
#define Light_Coms_TX_ANS                  ANSELCbits.ANSELC2
#define Light_Coms_TX_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define Light_Coms_TX_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define Light_Coms_TX_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define Light_Coms_TX_GetValue()           PORTCbits.RC2
#define Light_Coms_TX_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define Light_Coms_TX_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define Light_Coms_TX_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define Light_Coms_TX_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define Light_Coms_TX_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define Light_Coms_TX_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define Light_Coms_TX_SetAnalogMode()      do { ANSELCbits.ANSELC2 = 1; } while(0)
#define Light_Coms_TX_SetDigitalMode()     do { ANSELCbits.ANSELC2 = 0; } while(0)

// get/set RC3 aliases
#define Light_Coms_RX_TRIS                 TRISCbits.TRISC3
#define Light_Coms_RX_LAT                  LATCbits.LATC3
#define Light_Coms_RX_PORT                 PORTCbits.RC3
#define Light_Coms_RX_WPU                  WPUCbits.WPUC3
#define Light_Coms_RX_OD                   ODCONCbits.ODCC3
#define Light_Coms_RX_ANS                  ANSELCbits.ANSELC3
#define Light_Coms_RX_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define Light_Coms_RX_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define Light_Coms_RX_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define Light_Coms_RX_GetValue()           PORTCbits.RC3
#define Light_Coms_RX_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define Light_Coms_RX_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define Light_Coms_RX_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define Light_Coms_RX_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define Light_Coms_RX_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define Light_Coms_RX_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define Light_Coms_RX_SetAnalogMode()      do { ANSELCbits.ANSELC3 = 1; } while(0)
#define Light_Coms_RX_SetDigitalMode()     do { ANSELCbits.ANSELC3 = 0; } while(0)

// get/set RD1 aliases
#define BRIGHTNESS_BUTTON_TRIS                 TRISDbits.TRISD1
#define BRIGHTNESS_BUTTON_LAT                  LATDbits.LATD1
#define BRIGHTNESS_BUTTON_PORT                 PORTDbits.RD1
#define BRIGHTNESS_BUTTON_WPU                  WPUDbits.WPUD1
#define BRIGHTNESS_BUTTON_OD                   ODCONDbits.ODCD1
#define BRIGHTNESS_BUTTON_ANS                  ANSELDbits.ANSELD1
#define BRIGHTNESS_BUTTON_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define BRIGHTNESS_BUTTON_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define BRIGHTNESS_BUTTON_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define BRIGHTNESS_BUTTON_GetValue()           PORTDbits.RD1
#define BRIGHTNESS_BUTTON_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define BRIGHTNESS_BUTTON_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define BRIGHTNESS_BUTTON_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define BRIGHTNESS_BUTTON_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define BRIGHTNESS_BUTTON_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define BRIGHTNESS_BUTTON_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define BRIGHTNESS_BUTTON_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define BRIGHTNESS_BUTTON_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

// get/set RD2 aliases
#define COLOR_BUTTON_TRIS                 TRISDbits.TRISD2
#define COLOR_BUTTON_LAT                  LATDbits.LATD2
#define COLOR_BUTTON_PORT                 PORTDbits.RD2
#define COLOR_BUTTON_WPU                  WPUDbits.WPUD2
#define COLOR_BUTTON_OD                   ODCONDbits.ODCD2
#define COLOR_BUTTON_ANS                  ANSELDbits.ANSELD2
#define COLOR_BUTTON_SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define COLOR_BUTTON_SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define COLOR_BUTTON_Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define COLOR_BUTTON_GetValue()           PORTDbits.RD2
#define COLOR_BUTTON_SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define COLOR_BUTTON_SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)
#define COLOR_BUTTON_SetPullup()          do { WPUDbits.WPUD2 = 1; } while(0)
#define COLOR_BUTTON_ResetPullup()        do { WPUDbits.WPUD2 = 0; } while(0)
#define COLOR_BUTTON_SetPushPull()        do { ODCONDbits.ODCD2 = 0; } while(0)
#define COLOR_BUTTON_SetOpenDrain()       do { ODCONDbits.ODCD2 = 1; } while(0)
#define COLOR_BUTTON_SetAnalogMode()      do { ANSELDbits.ANSELD2 = 1; } while(0)
#define COLOR_BUTTON_SetDigitalMode()     do { ANSELDbits.ANSELD2 = 0; } while(0)

// get/set RD3 aliases
#define MODE_BUTTON_TRIS                 TRISDbits.TRISD3
#define MODE_BUTTON_LAT                  LATDbits.LATD3
#define MODE_BUTTON_PORT                 PORTDbits.RD3
#define MODE_BUTTON_WPU                  WPUDbits.WPUD3
#define MODE_BUTTON_OD                   ODCONDbits.ODCD3
#define MODE_BUTTON_ANS                  ANSELDbits.ANSELD3
#define MODE_BUTTON_SetHigh()            do { LATDbits.LATD3 = 1; } while(0)
#define MODE_BUTTON_SetLow()             do { LATDbits.LATD3 = 0; } while(0)
#define MODE_BUTTON_Toggle()             do { LATDbits.LATD3 = ~LATDbits.LATD3; } while(0)
#define MODE_BUTTON_GetValue()           PORTDbits.RD3
#define MODE_BUTTON_SetDigitalInput()    do { TRISDbits.TRISD3 = 1; } while(0)
#define MODE_BUTTON_SetDigitalOutput()   do { TRISDbits.TRISD3 = 0; } while(0)
#define MODE_BUTTON_SetPullup()          do { WPUDbits.WPUD3 = 1; } while(0)
#define MODE_BUTTON_ResetPullup()        do { WPUDbits.WPUD3 = 0; } while(0)
#define MODE_BUTTON_SetPushPull()        do { ODCONDbits.ODCD3 = 0; } while(0)
#define MODE_BUTTON_SetOpenDrain()       do { ODCONDbits.ODCD3 = 1; } while(0)
#define MODE_BUTTON_SetAnalogMode()      do { ANSELDbits.ANSELD3 = 1; } while(0)
#define MODE_BUTTON_SetDigitalMode()     do { ANSELDbits.ANSELD3 = 0; } while(0)

// get/set RF7 aliases
#define TROUBLE_TRIS                 TRISFbits.TRISF7
#define TROUBLE_LAT                  LATFbits.LATF7
#define TROUBLE_PORT                 PORTFbits.RF7
#define TROUBLE_WPU                  WPUFbits.WPUF7
#define TROUBLE_OD                   ODCONFbits.ODCF7
#define TROUBLE_ANS                  ANSELFbits.ANSELF7
#define TROUBLE_SetHigh()            do { LATFbits.LATF7 = 1; } while(0)
#define TROUBLE_SetLow()             do { LATFbits.LATF7 = 0; } while(0)
#define TROUBLE_Toggle()             do { LATFbits.LATF7 = ~LATFbits.LATF7; } while(0)
#define TROUBLE_GetValue()           PORTFbits.RF7
#define TROUBLE_SetDigitalInput()    do { TRISFbits.TRISF7 = 1; } while(0)
#define TROUBLE_SetDigitalOutput()   do { TRISFbits.TRISF7 = 0; } while(0)
#define TROUBLE_SetPullup()          do { WPUFbits.WPUF7 = 1; } while(0)
#define TROUBLE_ResetPullup()        do { WPUFbits.WPUF7 = 0; } while(0)
#define TROUBLE_SetPushPull()        do { ODCONFbits.ODCF7 = 0; } while(0)
#define TROUBLE_SetOpenDrain()       do { ODCONFbits.ODCF7 = 1; } while(0)
#define TROUBLE_SetAnalogMode()      do { ANSELFbits.ANSELF7 = 1; } while(0)
#define TROUBLE_SetDigitalMode()     do { ANSELFbits.ANSELF7 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/