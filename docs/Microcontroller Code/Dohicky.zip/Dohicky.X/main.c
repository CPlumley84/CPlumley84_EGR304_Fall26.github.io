/*
 * MAIN APPLICATION
 *
 * PIC18F57Q43 Curiosity Nano
 *
 * ============================================================
 * STANDALONE TEST MODE
 * ============================================================
 *
 * Set:
 *
 *      STANDALONE_TEST_MODE = 1
 *
 * to test the main controller without the temperature
 * and ambient-light PIC boards connected.
 *
 * Simulated communication states are controlled by:
 *
 *      TEST_TEMPERATURE_BITS
 *      TEST_LIGHT_BIT
 *
 * Temperature test states:
 *
 *      0b00 = Both temperature LEDs OFF
 *      0b10 = Low Temp LED ON
 *      0b01 = Low Temp LED ON
 *      0b11 = Both temperature LEDs ON
 *
 * Ambient-light test states:
 *
 *      0 = Dark   -> RGB array permitted
 *      1 = Bright -> RGB array disabled
 *
 * When the other PIC boards are available, change:
 *
 *      #define STANDALONE_TEST_MODE 1
 *
 * to:
 *
 *      #define STANDALONE_TEST_MODE 0
 *
 * ============================================================
 * COMMUNICATION
 * ============================================================
 *
 * Both UART links:
 *
 *      9600 baud
 *      8 data bits
 *      No parity
 *      1 stop bit
 *      Expected transmission interval = 500 ms
 *
 * ------------------------------------------------------------
 * UART3 - Temperature board
 * ------------------------------------------------------------
 *
 * RA3 = TX
 * RA4 = RX
 *
 * Expected messages:
 *
 *      T,00\r\n
 *      T,10\r\n
 *      T,01\r\n
 *      T,11\r\n
 *
 * Meaning:
 *
 *      00 -> Low Temp LED OFF / High Temp LED OFF
 *      10 -> Low Temp LED ON  / High Temp LED OFF
 *      01 -> Low Temp LED ON  / High Temp LED OFF
 *      11 -> Low Temp LED ON  / High Temp LED ON
 *
 * ------------------------------------------------------------
 * UART1 - Ambient-light board
 * ------------------------------------------------------------
 *
 * RC2 = TX
 * RC3 = RX
 *
 * Expected messages:
 *
 *      L,0\r\n
 *      L,1\r\n
 *
 * Meaning:
 *
 *      0 -> Dark   -> RGB array permitted
 *      1 -> Bright -> RGB array disabled
 *
 * ------------------------------------------------------------
 * COMMUNICATION HEALTH / TROUBLE LED
 * ------------------------------------------------------------
 *
 * The Trouble LED is normally illuminated continuously.
 *
 * If a UART channel fails to receive a valid message for
 * more than 5 seconds, the Trouble LED displays a diagnostic
 * flash pattern:
 *
 *      Solid ON = Both communication channels healthy
 *
 *      1 flash  = Ambient-light communication fault
 *
 *      2 flashes = Temperature communication fault
 *
 *      3 flashes = Both communication channels faulted
 *
 * Each flash is:
 *
 *      200 ms ON
 *      200 ms OFF
 *
 * After the required number of flashes, the LED remains
 * OFF for 1000 ms before repeating the fault code.
 *
 * A valid message from a failed channel immediately
 * restores that channel.
 *
 * ============================================================
 * RGB LED BANKS
 * ============================================================
 *
 * PWM1 OUT1 -> RC0 -> Red bank 1
 * PWM1 OUT2 -> RC1 -> Red bank 2
 *
 * PWM2 OUT1 -> RB0 -> Green bank 1
 * PWM2 OUT2 -> RB1 -> Green bank 2
 *
 * PWM3 OUT1 -> RB3 -> Blue bank
 *
 * PWM frequency = 1 kHz
 * PWM period    = 63999 counts
 *
 * ============================================================
 * INDICATOR LEDS
 * ============================================================
 *
 * RA5 = Trouble LED
 * RA6 = Low Temperature LED  (Nano pin 49)
 * RA7 = High Temperature LED (Nano pin 50)
 *
 * ============================================================
 * BUTTONS
 * ============================================================
 *
 * RD1 = Brightness
 *
 *      0%
 *      25%
 *      50%
 *      75%
 *      100%
 *      repeat
 *
 * RD2 = Static Color
 *
 *      Red
 *      Green
 *      Blue
 *      Yellow
 *      Cyan
 *      Magenta
 *      White
 *      repeat
 *
 * RD3 = Preset Mode
 *
 *      Mode 1: Orange <-> Yellow, slow pulse
 *      Mode 2: Blue <-> Green, slow pulse
 *      Mode 3: Green <-> Yellow, slow pulse
 *      Mode 4: White <-> Blue, slow pulse
 *      Mode 5: Solid White
 *
 * ============================================================
 */

#include "mcc_generated_files/system/system.h"

#include <stdint.h>
#include <stdbool.h>


/* ============================================================
 * TEST MODE CONFIGURATION
 * ============================================================ */

/*
 * 1 = Standalone test mode
 * 0 = Normal UART sensor operation
 */

#define STANDALONE_TEST_MODE       0


/*
 * Simulated communication states used ONLY when
 * STANDALONE_TEST_MODE = 1.
 *
 * Temperature:
 *
 * 0b00 = Both OFF
 * 0b10 = Low Temp ON
 * 0b01 = Low Temp ON
 * 0b11 = Both ON
 */

#define TEST_TEMPERATURE_BITS      0b11U


/*
 * Ambient light:
 *
 * 0 = Dark   -> RGB permitted
 * 1 = Bright -> RGB disabled
 */

#define TEST_LIGHT_BIT             0U


/* ============================================================
 * SYSTEM CONSTANTS
 * ============================================================ */

#define PWM_MAX_COUNT              63999UL

#define BUTTON_DEBOUNCE_MS         30UL

#define ANIMATION_STEP_MS          20UL


/*
 * Communication timeout.
 *
 * Expected messages arrive every 500 ms.
 * Five seconds corresponds to approximately
 * ten missed expected messages.
 */

#define UART_TIMEOUT_MS            5000UL


/*
 * Trouble LED diagnostic timing.
 */

#define TROUBLE_FLASH_ON_MS        200UL
#define TROUBLE_FLASH_OFF_MS       200UL
#define TROUBLE_FLASH_PAUSE_MS     1000UL


#define UART_BUFFER_SIZE           16U

#define BRIGHTNESS_LEVEL_COUNT     5U


/* ============================================================
 * APPLICATION TYPES
 * ============================================================ */

typedef enum
{
    COLOR_RED = 0,
    COLOR_GREEN,
    COLOR_BLUE,
    COLOR_YELLOW,
    COLOR_CYAN,
    COLOR_MAGENTA,
    COLOR_WHITE,
    COLOR_COUNT

} color_t;


typedef enum
{
    MODE_ORANGE_YELLOW = 0,
    MODE_BLUE_GREEN,
    MODE_GREEN_YELLOW,
    MODE_WHITE_BLUE,
    MODE_SOLID_WHITE,
    MODE_COUNT

} mode_t;


typedef enum
{
    DISPLAY_STATIC_COLOR = 0,
    DISPLAY_PRESET_MODE

} display_type_t;


typedef struct
{
    bool previousRawState;
    bool stableState;
    uint32_t changeTime;

} button_t;


/* ============================================================
 * GLOBAL TIME
 * ============================================================ */

static volatile uint32_t systemMilliseconds = 0UL;


/* ============================================================
 * USER SETTINGS
 * ============================================================ */

static const uint8_t brightnessLevels[BRIGHTNESS_LEVEL_COUNT] =
{
    0U,
    25U,
    50U,
    75U,
    100U
};


static uint8_t brightnessIndex = 4U;

static color_t selectedColor = COLOR_WHITE;

static mode_t selectedMode = MODE_ORANGE_YELLOW;

static display_type_t displayType = DISPLAY_STATIC_COLOR;


/* ============================================================
 * COMMUNICATION DATA
 * ============================================================ */

/*
 * Temperature:
 *
 * 00 -> Both OFF
 * 10 -> Low Temp ON
 * 01 -> Low Temp ON
 * 11 -> Both ON
 */

static uint8_t temperatureBits = 0U;


/*
 * Ambient light:
 *
 * false = Dark   -> RGB permitted
 * true  = Bright -> RGB disabled
 */

static bool lightIsBright = true;


static bool temperatureValid = false;

static bool lightValid = false;

static uint32_t lastTemperatureMessage = 0UL;

static uint32_t lastLightMessage = 0UL;


/* ============================================================
 * TROUBLE LED STATE
 * ============================================================ */

/*
 * Starting time of the current diagnostic
 * flash sequence.
 */

static uint32_t troublePatternStart = 0UL;


/*
 * Current fault code:
 *
 * 0 = healthy
 * 1 = light fault
 * 2 = temperature fault
 * 3 = both faults
 *
 * Used to restart the flash pattern whenever
 * the fault condition changes.
 */

static uint8_t previousTroubleCode = 0U;


/* ============================================================
 * UART RECEIVE BUFFERS
 * ============================================================ */

static char tempBuffer[UART_BUFFER_SIZE];

static uint8_t tempBufferIndex = 0U;


static char lightBuffer[UART_BUFFER_SIZE];

static uint8_t lightBufferIndex = 0U;


/* ============================================================
 * BUTTON STATES
 * ============================================================ */

static button_t brightnessButton =
{
    false,
    false,
    0UL
};


static button_t colorButton =
{
    false,
    false,
    0UL
};


static button_t modeButton =
{
    false,
    false,
    0UL
};


/* ============================================================
 * ANIMATION STATE
 * ============================================================ */

static uint32_t lastAnimationUpdate = 0UL;

static uint8_t animationPhase = 0U;

static bool animationIncreasing = true;


/* ============================================================
 * 1 ms SYSTEM TIMER CALLBACK
 * ============================================================ */

static void SystemTick(void)
{
    systemMilliseconds++;
}


/* ============================================================
 * PWM PERCENTAGE TO REGISTER COUNT
 * ============================================================ */

static uint16_t PWM_PercentToCount(uint8_t percent)
{
    if (percent >= 100U)
    {
        return (uint16_t)PWM_MAX_COUNT;
    }


    return (uint16_t)
    (
        (PWM_MAX_COUNT *
         (uint32_t)percent) / 100UL
    );
}


/* ============================================================
 * SET RGB LED BANK OUTPUTS
 * ============================================================ */

static void LED_SetBanks
(
    uint8_t redPercent,
    uint8_t greenPercent,
    uint8_t bluePercent
)
{
    uint16_t redDuty;
    uint16_t greenDuty;
    uint16_t blueDuty;


    redDuty =
        PWM_PercentToCount(redPercent);


    greenDuty =
        PWM_PercentToCount(greenPercent);


    blueDuty =
        PWM_PercentToCount(bluePercent);


    /*
     * RED BANKS
     */

    PWM1_16BIT_SetSlice1Output1DutyCycleRegister
    (
        redDuty
    );


    PWM1_16BIT_SetSlice1Output2DutyCycleRegister
    (
        redDuty
    );


    PWM1_16BIT_LoadBufferRegisters();


    /*
     * GREEN BANKS
     */

    PWM2_16BIT_SetSlice1Output1DutyCycleRegister
    (
        greenDuty
    );


    PWM2_16BIT_SetSlice1Output2DutyCycleRegister
    (
        greenDuty
    );


    PWM2_16BIT_LoadBufferRegisters();


    /*
     * BLUE BANK
     */

    PWM3_16BIT_SetSlice1Output1DutyCycleRegister
    (
        blueDuty
    );


    PWM3_16BIT_LoadBufferRegisters();
}


/* ============================================================
 * MASTER BRIGHTNESS
 * ============================================================ */

static uint8_t ScaleBrightness(uint8_t colorPercent)
{
    uint8_t masterBrightness;


    masterBrightness =
        brightnessLevels[brightnessIndex];


    return (uint8_t)
    (
        ((uint16_t)colorPercent *
         (uint16_t)masterBrightness) / 100U
    );
}


/* ============================================================
 * STATIC COLOR DISPLAY
 * ============================================================ */

static void DisplayStaticColor(void)
{
    uint8_t red = 0U;
    uint8_t green = 0U;
    uint8_t blue = 0U;


    switch (selectedColor)
    {
        case COLOR_RED:

            red = 100U;

            break;


        case COLOR_GREEN:

            green = 100U;

            break;


        case COLOR_BLUE:

            blue = 100U;

            break;


        case COLOR_YELLOW:

            red = 100U;
            green = 100U;

            break;


        case COLOR_CYAN:

            green = 100U;
            blue = 100U;

            break;


        case COLOR_MAGENTA:

            red = 100U;
            blue = 100U;

            break;


        case COLOR_WHITE:

            red = 100U;
            green = 100U;
            blue = 100U;

            break;


        default:

            red = 0U;
            green = 0U;
            blue = 0U;

            break;
    }


    LED_SetBanks
    (
        ScaleBrightness(red),
        ScaleBrightness(green),
        ScaleBrightness(blue)
    );
}


/* ============================================================
 * UPDATE ANIMATION PHASE
 * ============================================================ */

static void UpdateAnimationPhase(void)
{
    uint32_t now;


    now =
        systemMilliseconds;


    if
    (
        (now - lastAnimationUpdate) <
        ANIMATION_STEP_MS
    )
    {
        return;
    }


    lastAnimationUpdate = now;


    if (animationIncreasing)
    {
        if (animationPhase < 100U)
        {
            animationPhase++;
        }
        else
        {
            animationIncreasing = false;
        }
    }
    else
    {
        if (animationPhase > 0U)
        {
            animationPhase--;
        }
        else
        {
            animationIncreasing = true;
        }
    }
}


/* ============================================================
 * PRESET MODE DISPLAY
 * ============================================================ */

static void DisplayPresetMode(void)
{
    uint8_t red = 0U;
    uint8_t green = 0U;
    uint8_t blue = 0U;

    uint8_t pulse;


    UpdateAnimationPhase();


    /*
     * Slow pulse:
     *
     * 50% -> 100% -> 50%
     */

    if (animationPhase <= 50U)
    {
        pulse =
            (uint8_t)
            (
                50U + animationPhase
            );
    }
    else
    {
        pulse =
            (uint8_t)
            (
                150U - animationPhase
            );
    }


    switch (selectedMode)
    {
        /*
         * MODE 1
         *
         * Orange -> Yellow -> Orange
         */

        case MODE_ORANGE_YELLOW:

            red = 100U;


            green =
                (uint8_t)
                (
                    35U +
                    (
                        ((uint16_t)animationPhase *
                         65U) / 100U
                    )
                );


            blue = 0U;

            break;


        /*
         * MODE 2
         *
         * Blue -> Green -> Blue
         */

        case MODE_BLUE_GREEN:

            red = 0U;

            green =
                animationPhase;

            blue =
                (uint8_t)
                (
                    100U - animationPhase
                );

            break;


        /*
         * MODE 3
         *
         * Green -> Yellow -> Green
         */

        case MODE_GREEN_YELLOW:

            red =
                animationPhase;

            green = 100U;

            blue = 0U;

            break;


        /*
         * MODE 4
         *
         * White -> Blue -> White
         */

        case MODE_WHITE_BLUE:

            red =
                (uint8_t)
                (
                    100U - animationPhase
                );


            green =
                (uint8_t)
                (
                    100U - animationPhase
                );


            blue = 100U;

            break;


        /*
         * MODE 5
         *
         * Solid White
         */

        case MODE_SOLID_WHITE:

            red = 100U;
            green = 100U;
            blue = 100U;

            pulse = 100U;

            break;


        default:

            red = 0U;
            green = 0U;
            blue = 0U;

            break;
    }


    /*
     * Apply preset pulse.
     */

    red =
        (uint8_t)
        (
            ((uint16_t)red *
             (uint16_t)pulse) / 100U
        );


    green =
        (uint8_t)
        (
            ((uint16_t)green *
             (uint16_t)pulse) / 100U
        );


    blue =
        (uint8_t)
        (
            ((uint16_t)blue *
             (uint16_t)pulse) / 100U
        );


    /*
     * Apply user-selected master brightness.
     */

    LED_SetBanks
    (
        ScaleBrightness(red),
        ScaleBrightness(green),
        ScaleBrightness(blue)
    );
}


/* ============================================================
 * RGB ARRAY MASTER CONTROL
 * ============================================================ */

static void UpdateRGBArray(void)
{
    /*
     * No valid ambient-light communication:
     *
     * RGB array OFF.
     */

    if (!lightValid)
    {
        LED_SetBanks
        (
            0U,
            0U,
            0U
        );

        return;
    }


    /*
     * Light state = 1:
     *
     * Bright ambient conditions.
     * RGB array OFF.
     */

    if (lightIsBright)
    {
        LED_SetBanks
        (
            0U,
            0U,
            0U
        );

        return;
    }


    /*
     * User selected 0% brightness:
     *
     * RGB array OFF.
     */

    if
    (
        brightnessLevels[brightnessIndex] ==
        0U
    )
    {
        LED_SetBanks
        (
            0U,
            0U,
            0U
        );

        return;
    }


    /*
     * Display selected output.
     */

    if
    (
        displayType ==
        DISPLAY_STATIC_COLOR
    )
    {
        DisplayStaticColor();
    }
    else
    {
        DisplayPresetMode();
    }
}


/* ============================================================
 * TEMPERATURE LED CONTROL
 * ============================================================ */

static void UpdateTemperatureLEDs(void)
{
    /*
     * Invalid temperature communication:
     *
     * Both LEDs OFF.
     */

    if (!temperatureValid)
    {
        TEMP_LED_1_SetLow();

        TEMP_LED_2_SetLow();

        return;
    }


    /*
     * Temperature communication table:
     *
     * 00 -> LED1 OFF / LED2 OFF
     * 10 -> LED1 ON  / LED2 OFF
     * 01 -> LED1 ON  / LED2 OFF
     * 11 -> LED1 ON  / LED2 ON
     */

    switch (temperatureBits)
    {
        case 0x00U:

            TEMP_LED_1_SetLow();

            TEMP_LED_2_SetLow();

            break;


        case 0x02U:     /* binary 10 */

            TEMP_LED_1_SetHigh();

            TEMP_LED_2_SetLow();

            break;


        case 0x01U:     /* binary 01 */

            TEMP_LED_1_SetHigh();

            TEMP_LED_2_SetLow();

            break;


        case 0x03U:     /* binary 11 */

            TEMP_LED_1_SetHigh();

            TEMP_LED_2_SetHigh();

            break;


        default:

            TEMP_LED_1_SetLow();

            TEMP_LED_2_SetLow();

            break;
    }
}


/* ============================================================
 * TROUBLE LED / COMMUNICATION HEALTH
 *
 * Solid ON:
 *      Both UART links healthy
 *
 * 1 flash:
 *      Ambient-light UART fault
 *
 * 2 flashes:
 *      Temperature UART fault
 *
 * 3 flashes:
 *      Both UART links faulted
 *
 * ============================================================ */

static void UpdateTroubleLED(void)
{

#if STANDALONE_TEST_MODE

    /*
     * Standalone test mode simulates
     * two healthy communication links.
     */

    temperatureBits =
        (uint8_t)
        (
            TEST_TEMPERATURE_BITS & 0x03U
        );


    lightIsBright =
        (TEST_LIGHT_BIT != 0U);


    temperatureValid =
        true;


    lightValid =
        true;


    /*
     * Solid ON = healthy.
     */

    TROUBLE_SetHigh();


    return;

#else

    uint32_t now;

    uint32_t elapsed;

    uint32_t flashCycleTime;

    uint32_t activeFlashTime;

    uint32_t patternLength;

    uint8_t troubleCode;


    now =
        systemMilliseconds;


    /* ========================================================
     * CHECK TEMPERATURE COMMUNICATION TIMEOUT
     * ======================================================== */

    if (temperatureValid)
    {
        if
        (
            (now - lastTemperatureMessage) >
            UART_TIMEOUT_MS
        )
        {
            temperatureValid =
                false;
        }
    }


    /* ========================================================
     * CHECK AMBIENT-LIGHT COMMUNICATION TIMEOUT
     * ======================================================== */

    if (lightValid)
    {
        if
        (
            (now - lastLightMessage) >
            UART_TIMEOUT_MS
        )
        {
            lightValid =
                false;
        }
    }


    /* ========================================================
     * DETERMINE TROUBLE CODE
     * ======================================================== */

    if
    (
        temperatureValid &&
        lightValid
    )
    {
        troubleCode =
            0U;
    }

    else if
    (
        temperatureValid &&
        (!lightValid)
    )
    {
        /*
         * Ambient-light communication fault.
         */

        troubleCode =
            1U;
    }

    else if
    (
        (!temperatureValid) &&
        lightValid
    )
    {
        /*
         * Temperature communication fault.
         */

        troubleCode =
            2U;
    }

    else
    {
        /*
         * Both communication channels faulted.
         */

        troubleCode =
            3U;
    }


    /* ========================================================
     * RESTART PATTERN IF FAULT CONDITION CHANGES
     * ======================================================== */

    if
    (
        troubleCode !=
        previousTroubleCode
    )
    {
        previousTroubleCode =
            troubleCode;


        troublePatternStart =
            now;
    }


    /* ========================================================
     * HEALTHY
     *
     * Solid Trouble LED.
     * ======================================================== */

    if (troubleCode == 0U)
    {
        TROUBLE_SetHigh();


        return;
    }


    /* ========================================================
     * FAULT FLASH PATTERN
     * ======================================================== */

    flashCycleTime =
        TROUBLE_FLASH_ON_MS +
        TROUBLE_FLASH_OFF_MS;


    activeFlashTime =
        (uint32_t)troubleCode *
        flashCycleTime;


    patternLength =
        activeFlashTime +
        TROUBLE_FLASH_PAUSE_MS;


    elapsed =
        now -
        troublePatternStart;


    /*
     * Restart the pattern after the
     * complete flash/pause sequence.
     */

    if (elapsed >= patternLength)
    {
        troublePatternStart =
            now;


        elapsed =
            0UL;
    }


    /*
     * Active flashing portion.
     */

    if (elapsed < activeFlashTime)
    {
        if
        (
            (elapsed % flashCycleTime) <
            TROUBLE_FLASH_ON_MS
        )
        {
            TROUBLE_SetHigh();
        }
        else
        {
            TROUBLE_SetLow();
        }
    }

    /*
     * Pause after flash code.
     */

    else
    {
        TROUBLE_SetLow();
    }

#endif
}


/* ============================================================
 * TEMPERATURE UART MESSAGE PARSER
 *
 * Valid messages:
 *
 *      T,00
 *      T,10
 *      T,01
 *      T,11
 *
 * ============================================================ */

static void ParseTemperatureMessage(char *message)
{
    uint8_t state;


    if (message[0] != 'T')
    {
        return;
    }


    if (message[1] != ',')
    {
        return;
    }


    if
    (
        ((message[2] != '0') &&
         (message[2] != '1')) ||
        ((message[3] != '0') &&
         (message[3] != '1'))
    )
    {
        return;
    }


    /*
     * Reject extra characters.
     */

    if (message[4] != '\0')
    {
        return;
    }


    /*
     * Convert ASCII bits into numeric value.
     *
     * 00 -> 0
     * 01 -> 1
     * 10 -> 2
     * 11 -> 3
     */

    state =
        0U;


    if (message[2] == '1')
    {
        state |=
            0x02U;
    }


    if (message[3] == '1')
    {
        state |=
            0x01U;
    }


    temperatureBits =
        state;


    temperatureValid =
        true;


    lastTemperatureMessage =
        systemMilliseconds;
}


/* ============================================================
 * AMBIENT-LIGHT UART MESSAGE PARSER
 *
 * Valid messages:
 *
 *      L,0
 *      L,1
 *
 * 0 = Dark
 * 1 = Bright
 *
 * ============================================================ */

static void ParseLightMessage(char *message)
{
    if (message[0] != 'L')
    {
        return;
    }


    if (message[1] != ',')
    {
        return;
    }


    if
    (
        (message[2] != '0') &&
        (message[2] != '1')
    )
    {
        return;
    }


    /*
     * Reject extra characters.
     */

    if (message[3] != '\0')
    {
        return;
    }


    lightIsBright =
        (message[2] == '1');


    lightValid =
        true;


    lastLightMessage =
        systemMilliseconds;
}


/* ============================================================
 * UART3 TEMPERATURE RECEIVER
 * ============================================================ */

static void ProcessTemperatureUART(void)
{

#if !STANDALONE_TEST_MODE

    uint8_t ch;


    while (UART3_IsRxReady())
    {
        ch =
            UART3_Read();


        /*
         * CR or LF terminates a message.
         */

        if
        (
            (ch == '\r') ||
            (ch == '\n')
        )
        {
            if (tempBufferIndex > 0U)
            {
                tempBuffer[tempBufferIndex] =
                    '\0';


                ParseTemperatureMessage
                (
                    tempBuffer
                );


                tempBufferIndex =
                    0U;
            }
        }

        else
        {
            if
            (
                tempBufferIndex <
                (UART_BUFFER_SIZE - 1U)
            )
            {
                tempBuffer[tempBufferIndex] =
                    (char)ch;


                tempBufferIndex++;
            }

            else
            {
                /*
                 * Buffer overflow:
                 * discard incomplete message.
                 */

                tempBufferIndex =
                    0U;
            }
        }
    }

#endif
}


/* ============================================================
 * UART1 AMBIENT-LIGHT RECEIVER
 * ============================================================ */

static void ProcessLightUART(void)
{

#if !STANDALONE_TEST_MODE

    uint8_t ch;


    while (UART1_IsRxReady())
    {
        ch =
            UART1_Read();


        /*
         * CR or LF terminates a message.
         */

        if
        (
            (ch == '\r') ||
            (ch == '\n')
        )
        {
            if (lightBufferIndex > 0U)
            {
                lightBuffer[lightBufferIndex] =
                    '\0';


                ParseLightMessage
                (
                    lightBuffer
                );


                lightBufferIndex =
                    0U;
            }
        }

        else
        {
            if
            (
                lightBufferIndex <
                (UART_BUFFER_SIZE - 1U)
            )
            {
                lightBuffer[lightBufferIndex] =
                    (char)ch;


                lightBufferIndex++;
            }

            else
            {
                /*
                 * Buffer overflow:
                 * discard incomplete message.
                 */

                lightBufferIndex =
                    0U;
            }
        }
    }

#endif
}


/* ============================================================
 * BUTTON DEBOUNCE
 *
 * Returns TRUE once for each valid press.
 * ============================================================ */

static bool ButtonPressed
(
    button_t *button,
    bool rawPressed
)
{
    uint32_t now;


    now =
        systemMilliseconds;


    if
    (
        rawPressed !=
        button->previousRawState
    )
    {
        button->previousRawState =
            rawPressed;


        button->changeTime =
            now;
    }


    if
    (
        (now - button->changeTime) >=
        BUTTON_DEBOUNCE_MS
    )
    {
        if
        (
            rawPressed !=
            button->stableState
        )
        {
            button->stableState =
                rawPressed;


            if
            (
                button->stableState
            )
            {
                return true;
            }
        }
    }


    return false;
}


/* ============================================================
 * BUTTON PROCESSING
 * ============================================================ */

static void ProcessButtons(void)
{
    bool brightnessPressed;
    bool colorPressed;
    bool modePressed;


    /*
     * CURRENT BUTTON CONFIGURATION:
     *
     * Buttons are active LOW.
     *
     * Released = HIGH
     * Pressed  = LOW
     */

    brightnessPressed =
        (BRIGHTNESS_BUTTON_GetValue() == 0);


    colorPressed =
        (COLOR_BUTTON_GetValue() == 0);


    modePressed =
        (MODE_BUTTON_GetValue() == 0);


    /* ========================================================
     * BUTTON 1 - BRIGHTNESS
     *
     * 0 -> 25 -> 50 -> 75 -> 100 -> 0
     * ======================================================== */

    if
    (
        ButtonPressed
        (
            &brightnessButton,
            brightnessPressed
        )
    )
    {
        brightnessIndex++;


        if
        (
            brightnessIndex >=
            BRIGHTNESS_LEVEL_COUNT
        )
        {
            brightnessIndex =
                0U;
        }
    }


    /* ========================================================
     * BUTTON 2 - STATIC COLOR
     * ======================================================== */

    if
    (
        ButtonPressed
        (
            &colorButton,
            colorPressed
        )
    )
    {
        displayType =
            DISPLAY_STATIC_COLOR;


        selectedColor =
            (color_t)
            (selectedColor + 1);


        if
        (
            selectedColor >=
            COLOR_COUNT
        )
        {
            selectedColor =
                COLOR_RED;
        }
    }


    /* ========================================================
     * BUTTON 3 - PRESET MODE
     * ======================================================== */

    if
    (
        ButtonPressed
        (
            &modeButton,
            modePressed
        )
    )
    {
        displayType =
            DISPLAY_PRESET_MODE;


        selectedMode =
            (mode_t)
            (selectedMode + 1);


        if
        (
            selectedMode >=
            MODE_COUNT
        )
        {
            selectedMode =
                MODE_ORANGE_YELLOW;
        }


        animationPhase =
            0U;


        animationIncreasing =
            true;


        lastAnimationUpdate =
            systemMilliseconds;
    }
}


/* ============================================================
 * MAIN
 * ============================================================ */

int main(void)
{
    /*
     * Initialize MCC-generated hardware.
     */

    SYSTEM_Initialize();


    /*
     * Register 1 ms TMR0 callback.
     */

    TMR0_PeriodMatchCallbackRegister
    (
        SystemTick
    );


    /*
     * Enable interrupts.
     */

    INTERRUPT_GlobalInterruptEnable();


    /*
     * Safe startup:
     *
     * RGB array OFF.
     */

    LED_SetBanks
    (
        0U,
        0U,
        0U
    );


    /*
     * Temperature LEDs OFF initially.
     */

    TEMP_LED_1_SetLow();

    TEMP_LED_2_SetLow();


#if STANDALONE_TEST_MODE

    /*
     * ========================================================
     * STANDALONE TEST INITIALIZATION
     * ========================================================
     */

    temperatureBits =
        (uint8_t)
        (
            TEST_TEMPERATURE_BITS & 0x03U
        );


    lightIsBright =
        (TEST_LIGHT_BIT != 0U);


    temperatureValid =
        true;


    lightValid =
        true;


    /*
     * Solid ON = healthy.
     */

    TROUBLE_SetHigh();


    previousTroubleCode =
        0U;


#else

    /*
     * ========================================================
     * NORMAL SYSTEM INITIALIZATION
     * ========================================================
     *
     * Neither communication channel is valid until
     * its first valid message is received.
     *
     * Therefore startup initially represents:
     *
     *      3 flashes = both links unavailable
     */

    temperatureValid =
        false;


    lightValid =
        false;


    previousTroubleCode =
        3U;


    troublePatternStart =
        systemMilliseconds;


    /*
     * Begin first fault flash immediately.
     */

    TROUBLE_SetHigh();

#endif


    /*
     * ========================================================
     * MAIN APPLICATION LOOP
     * ========================================================
     */

    while (1)
    {
        /*
         * UART receivers.
         */

        ProcessTemperatureUART();

        ProcessLightUART();


        /*
         * Local push buttons.
         */

        ProcessButtons();


        /*
         * Communication health / diagnostic LED.
         */

        UpdateTroubleLED();


        /*
         * Temperature indicator LEDs.
         */

        UpdateTemperatureLEDs();


        /*
         * RGB array.
         */

        UpdateRGBArray();
    }
}